import {
  GET_USER_ORDERS,
  GET_USER_ORDERS_FAIL,
  GET_RESTAURANT_ORDERS,
  GET_RESTAURANT_ORDERS_FAIL,
} from "../actions/type";
const initalState = {
  orders: [],
};

export default function (state = initalState, action) {
  const { payload, type } = action;
  switch (type) {
    case GET_USER_ORDERS:
    case GET_RESTAURANT_ORDERS:
      return { ...state, orders: payload };
    case GET_USER_ORDERS_FAIL:
    case GET_RESTAURANT_ORDERS_FAIL:
      return { ...state, orders: [] };
    default:
      return state;
  }
}
