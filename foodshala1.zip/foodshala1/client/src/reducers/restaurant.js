import {
  LOGIN_RESTAURANT_SUCCESS,
  REGISTER_RESTAURANT_SUCCESS,
  LOGIN_RESTAURANT_FAIL,
  REGISTER_RESTAURANT_FAIL,
  LOAD_RESTAURANT,
  LOGOUT,
  RESTAURANT_AUTH_ERROR,
} from "../actions/type";

const initialState = {
  rtoken: localStorage.getItem("rtoken"),
  isAuthenticated: false,
  loading: true,
  restaurant: null,
};
export default function (state = initialState, action) {
  const { type, payload } = action;
  switch (type) {
    case LOAD_RESTAURANT:
      return {
        ...state,
        isAuthenticated: true,
        loading: false,
        restaurant: payload,
      };
    case LOGIN_RESTAURANT_SUCCESS:
    case REGISTER_RESTAURANT_SUCCESS:
      localStorage.setItem("rtoken", payload.token);
      return {
        ...state,
        ...payload,
        isAuthenticated: true,
        loading: false,
      };
    case RESTAURANT_AUTH_ERROR:
    case LOGIN_RESTAURANT_FAIL:
    case REGISTER_RESTAURANT_FAIL:
    case LOGOUT:
      localStorage.removeItem("rtoken");
      return {
        ...state,
        isAuthenticated: false,
        loading: false,
      };
    default:
      return state;
  }
}
