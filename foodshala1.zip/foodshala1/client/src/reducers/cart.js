import { ADD_TO_CART, REMOVE_FROM_CART, CLEAR_CART } from "../actions/type";
const initalState = {
  cart: [],
};

export default function (state = initalState, action) {
  const { type, payload } = action;
  switch (type) {
    case ADD_TO_CART:
      return {
        ...state,
        cart: state.cart.concat(payload),
      };
    case REMOVE_FROM_CART:
      return {
        ...state,
        cart: state.cart.filter((item) => item.pid !== payload),
      };
    case CLEAR_CART:
      return {
        ...state,
        cart: [],
      };
    default:
      return state;
  }
}
