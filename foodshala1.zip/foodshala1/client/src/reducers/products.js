import {
  GET_PRODUCTS,
  GET_PRODUCTS_BY_ID,
  GET_PRODUCTS_FAIL,
  GET_PRODUCTS_BY_ID_FAIL,
} from "../actions/type";

const initialState = {
  loading: true,
  products: [],
};

export default function (state = initialState, action) {
  const { type, payload } = action;

  switch (type) {
    case GET_PRODUCTS:
    case GET_PRODUCTS_BY_ID:
      return {
        ...state,
        loading: false,
        products: payload.products,
      };
    case GET_PRODUCTS_FAIL:
    case GET_PRODUCTS_BY_ID_FAIL:
      return {
        ...state,
        loading: false,
        products: [],
      };
    default:
      return state;
  }
}
