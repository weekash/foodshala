import { combineReducers } from "redux";
import user from "./user";
import { persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";
import restaurant from "./restaurant";
import products from "./products";
import alert from "./alert";
import cart from "./cart";
import orders from "./orders";
const persistConfig = {
  key: "root",
  storage,
  whitelist: ["cart"],
};
const rootReducer = combineReducers({
  user,
  restaurant,
  alert,
  products,
  cart,
  orders,
});
export default persistReducer(persistConfig, rootReducer);
