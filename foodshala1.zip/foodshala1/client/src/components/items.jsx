import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { addToCart } from "../actions/cart";
const Items = ({ products, addToCart, isRestaurant, cart }) => {
  const checkFirst = (index) => {
    let id = products[index].pid;
    let add = true;
    for (let i = 0; i < cart.length; i++) {
      if (cart[i].pid === id) add = false;
    }
    if (add) addToCart(products[index]);
  };
  return (
    <div id="items">
      {products.map(({ pname, restaurantName, price, info }, index) => {
        return (
          <div className="item">
            <img src="/food.jpg" />
            <div className="item-details">
              <h1>{pname}</h1>
              <h3>{restaurantName}</h3>
              <div>
                <span>&#8377;{price}</span>
              </div>
              <p>{info}</p>
              {!isRestaurant ? (
                <button className="btn" onClick={() => checkFirst(index)}>
                  Add to Cart
                </button>
              ) : null}
            </div>
          </div>
        );
      })}
    </div>
  );
};
const mapStateToProps = (state) => ({
  products: state.products.products,
  cart: state.cart.cart,
  isRestaurant: state.restaurant.isAuthenticated,
});
export default connect(mapStateToProps, { addToCart })(Items);
