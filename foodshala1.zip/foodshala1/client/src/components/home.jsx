import React, { useEffect } from "react";
import Banner from "./banner";
import Items from "./items";
import { connect } from "react-redux";
import { getAllProducts } from "../actions/products";
const Home = ({ getAllProducts }) => {
  useEffect(() => {
    getAllProducts();
  });
  return (
    <>
      <Banner />
      <Items />
    </>
  );
};

export default connect(null, { getAllProducts })(Home);
