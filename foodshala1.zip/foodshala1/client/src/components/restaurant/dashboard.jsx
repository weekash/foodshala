import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { getMyProducts } from "../../actions/products";
import { getRestaurantOrders } from "../../actions/orders";
import { Redirect } from "react-router-dom";
const RestaurantDashboard = ({
  products,
  orders,
  getMyProducts,
  isAuthenticated,
  getRestaurantOrders,
}) => {
  const [state, setState] = useState({
    displayOrders: true,
  });
  useEffect(() => {
    getMyProducts();
    getRestaurantOrders();
  }, [getMyProducts, getRestaurantOrders]);
  const { displayOrders } = state;

  return (
    <div className="dashboard">
      <h1>Welcome Restaurant {displayOrders}</h1>

      <div className="dashboard-options">
        <span
          onClick={() => setState({ displayOrders: true })}
          className={displayOrders ? "dashboard-option-active" : null}
        >
          Orders
        </span>
        <span
          onClick={() => setState({ displayOrders: false })}
          className={!displayOrders ? "dashboard-option-active" : null}
        >
          Products
        </span>
      </div>

      {displayOrders ? (
        <>
          <p>Showing Orders</p>

          <div className="orders">
            {orders.map(({ pname, username, price, status }) => {
              return (
                <div className="order">
                  <h1>{pname}</h1>
                  <h3>
                    Deliver To : <b>{username}</b>
                  </h3>
                  <p>&#8377;{price}</p>
                  <p>
                    Status: <b>{status}</b>
                  </p>
                </div>
              );
            })}
          </div>
        </>
      ) : (
        <>
          <p>Showing Products</p>
          <a className="btn" href="/restaurant/addproduct">
            ADD PRODUCT
          </a>
          <div className="products">
            {products.map(({ pid, pname, price, info, category }) => {
              return (
                <div className="product" key={pid}>
                  <h1>{pname}</h1>
                  <h3>{price}</h3>
                  <p>{info}</p>
                  <p>{category}</p>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
};
const mapStateToProps = (state) => ({
  products: state.products.products,
  orders: state.orders.orders,
  isAuthenticated: state.restaurant.isAuthenticated,
});
export default connect(mapStateToProps, { getMyProducts, getRestaurantOrders })(
  RestaurantDashboard
);
