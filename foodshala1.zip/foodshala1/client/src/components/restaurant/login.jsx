import React, { useState } from "react";
import { connect } from "react-redux";
import { loginRestaurant } from "../../actions/restaurant";
import Alert from "../alert";
import { Redirect } from "react-router-dom";
const RestaurantLogin = ({
  loginRestaurant,
  isAuthenticated,
  isRestaurant,
}) => {
  const [state, setState] = useState({
    email: "",
    password: "",
  });
  const handleText = (e) => {
    setState({
      ...state,
      [e.target.name]: e.target.value,
    });
  };
  const submitForm = (e) => {
    e.preventDefault();
    const { email, password } = state;
    loginRestaurant(email, password);
  };
  if (isRestaurant) return <Redirect to="/restaurant/dashboard" />;
  if (isAuthenticated) return <Redirect to="/" />;
  return (
    <div className="blur">
      <form onSubmit={submitForm} className="form">
        <Alert />
        <a href="/" className="home-btn">
          +
        </a>
        <h1>Restaurant Login </h1>
        <div>
          <label>Email</label>
          <input type="email" name="email" onChange={handleText} required />
          <label>Password</label>
          <input
            type="password"
            name="password"
            onChange={handleText}
            required
          />
          <input type="submit" value="Login" className="gradient1" />
        </div>
        <a href="/restaurant/register">
          Don't have an account ? Create one now...
        </a>
        <a href="/user/login">Not a restaurant. Continue as user</a>
      </form>
    </div>
  );
};
const mapStateToProps = (state) => ({
  isAuthenticated:
    state.user.isAuthenticated || state.restaurant.isAuthenticated,
  isRestaurant: state.restaurant.isAuthenticated,
});

export default connect(mapStateToProps, { loginRestaurant })(RestaurantLogin);
