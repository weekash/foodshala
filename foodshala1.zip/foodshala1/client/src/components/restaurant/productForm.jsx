import React, { useState } from "react";
import { addProduct } from "../../actions/products";
import { connect } from "react-redux";
import Alert from "../alert";
const ProductForm = ({ addProduct }) => {
  const [state, setState] = useState({
    pname: "",
    price: null,
    info: "",
    category: "",
  });
  const handleText = (e) => {
    setState({
      ...state,
      [e.target.name]: e.target.value,
    });
  };
  const changeCategory = (e) => {
    setState({ ...state, preference: e.target.value });
  };
  const submitForm = (e) => {
    e.preventDefault();
    const { pname, price, info, category } = state;
    addProduct(pname, price, info, category);
  };
  return (
    <div className="blur">
      <form class="form" onSubmit={submitForm}>
        <Alert />
        <a href="/restaurant/dashboard" className="home-btn">
          +
        </a>
        <label>Product Name</label>
        <input type="text" name="pname" required onChange={handleText} />
        <label>Product Price</label>
        <input type="number" name="price" required onChange={handleText} />
        <label>Product Info</label>
        <input type="text" name="info" required onChange={handleText} />
        <label>Product Category (veg/non-veg)</label>
        <div id="radio-group">
          <div>
            <input
              type="radio"
              value="veg"
              name="category"
              onChange={(e) => changeCategory(e)}
            />
            <span>Veg</span>
          </div>
          <div>
            <input
              type="radio"
              value="non-veg"
              name="category"
              onChange={(e) => changeCategory(e)}
            />
            <span>Non-Veg</span>
          </div>
        </div>
        <input type="submit" value="ADD Product" onChange={handleText} />
      </form>
    </div>
  );
};

export default connect(null, { addProduct })(ProductForm);
