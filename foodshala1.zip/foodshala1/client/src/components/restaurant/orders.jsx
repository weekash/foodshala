import React, { useEffect } from "react";
import { connect } from "react-redux";
import { getRestaurantOrders } from "../../actions/orders";
const RestaurantOrders = ({ items, getRestaurantOrders }) => {
  useEffect(() => {
    getRestaurantOrders();
  }, []);
  return (
    <div id="cart">
      <h1>Your Orders:</h1>
      <div id="cart-items">
        {items.map(({ username, pname, restaurantName, price }, index) => (
          <div className="cart-item" key={index}>
            <h1>{username}</h1>
            <h3>{pname}</h3>
            <h3>{restaurantName}</h3>
            <p>Price: &#8377; {price}</p>
          </div>
        ))}
      </div>
      {!items.length ? <h2>You don't have any orders</h2> : null}
    </div>
  );
};
const mapStateToProps = (state) => ({
  items: state.orders.orders,
});

export default connect(mapStateToProps, { getRestaurantOrders })(
  RestaurantOrders
);
