import React from "react";
import { connect } from "react-redux";
import { Route, Redirect } from "react-router-dom";

const PrivateRoute = ({
  component: Component,
  isAuthenticated,
  loading,
  isUser,
  ...rest
}) => (
  <Route
    {...rest}
    render={(props) =>
      !isAuthenticated && !loading ? (
        <Redirect to="/restaurant/login" />
      ) : (
        <Component {...props} />
      )
    }
  />
);

const mapStateToProps = (state) => ({
  isAuthenticated: state.restaurant.isAuthenticated,
  loading: state.restaurant.loading,
  isUser: state.user.isAuthenticated,
});

export default connect(mapStateToProps)(PrivateRoute);
