import React, { useState } from "react";
import { connect } from "react-redux";
import { registerRestaurant } from "../../actions/restaurant";
import { Redirect } from "react-router-dom";
import Alert from "../alert";
const RestaurantRegister = ({
  registerRestaurant,
  isAuthenticated,
  isRestaurant,
}) => {
  const [state, setState] = useState({
    restaurantName: "",
    email: "",
    password: "",
  });
  const handleText = (e) => {
    setState({
      ...state,
      [e.target.name]: e.target.value,
    });
  };
  const submitForm = (e) => {
    e.preventDefault();

    const { restaurantName, email, password } = state;
    registerRestaurant(restaurantName, email, password);
  };
  if (isRestaurant) return <Redirect to="/restaurant/dashboard" />;
  if (isAuthenticated) return <Redirect to="/" />;
  return (
    <div className="blur">
      <form onSubmit={submitForm} className="form">
        <Alert />
        <a href="/" className="home-btn">
          +
        </a>
        <h1>Restaurant Registration </h1>
        <div>
          <label>Restaurant name</label>
          <input
            type="text"
            name="restaurantName"
            onChange={handleText}
            required
          />
          <label>Email</label>
          <input type="email" name="email" onChange={handleText} required />
          <label>Password</label>
          <input
            type="password"
            name="password"
            onChange={handleText}
            required
          />
          <input type="submit" value="Register" className="gradient2" />
        </div>

        <a href="/restaurant/login">Already have an account ? Login Now</a>
      </form>
    </div>
  );
};
const mapStateToProps = (state) => ({
  isAuthenticated:
    state.user.isAuthenticated || state.restaurant.isAuthenticated,
  isRestaurant: state.restaurant.isAuthenticated,
});
export default connect(mapStateToProps, { registerRestaurant })(
  RestaurantRegister
);
