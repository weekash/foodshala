import React, { useEffect } from "react";
import { connect } from "react-redux";
import { logout } from "../actions/user";
const Nav = ({ isAuthenticated, logout, isUser, isRestaurant, count }) => {
  return (
    <div id="nav">
      <a href="/">
        <h1>FoodShala</h1>
      </a>
      <ul>
        {isRestaurant ? (
          <li>
            <a href="/restaurant/dashboard">Dashboard</a>
          </li>
        ) : null}
        {!isRestaurant || !count ? <li className="count">{count}</li> : null}
        {!isRestaurant ? (
          <li>
            <a href="/user/cart">
              <i className="fas fa-shopping-cart"></i> My Cart
            </a>
          </li>
        ) : null}
        {isUser ? (
          <li>
            <a href="/user/orders">My Orders</a>
          </li>
        ) : null}
        {isAuthenticated ? (
          <li onClick={logout}>Logout</li>
        ) : (
          <li>
            <a href="/user/login">Login</a>
          </li>
        )}
      </ul>
    </div>
  );
};
const mapStateToProps = (store) => ({
  isAuthenticated:
    store.user.isAuthenticated || store.restaurant.isAuthenticated,
  isUser: store.user.isAuthenticated,
  isRestaurant: store.restaurant.isAuthenticated,
  count: store.cart.cart.length,
});
export default connect(mapStateToProps, { logout })(Nav);
