import React from "react";
const Banner = () => {
  return (
    <div id="banner">
      <div id="banner-text">
        <h1>Craving for some delicious food </h1>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime itaque
          corporis, omnis ab eius sapiente esse dignissimos repellat amet dolor!
        </p>
        <div id="banner-btns">
          <a href="/user/login">
            <button className="btn">Login as Customer</button>
          </a>
          <a href="/restaurant/login">
            <button className="btn">Login as Restaurant</button>
          </a>
        </div>
      </div>
      <img src="/banner.svg" />
    </div>
  );
};

export default Banner;
