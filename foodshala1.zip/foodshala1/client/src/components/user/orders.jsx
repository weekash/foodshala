import React, { useEffect } from "react";
import { connect } from "react-redux";
import { getUserOrders } from "../../actions/orders";
const Orders = ({ items, getUserOrders }) => {
  useEffect(() => {
    getUserOrders();
  }, []);
  return (
    <div id="cart">
      <h1>Following Items you have ordered:</h1>
      <div id="cart-items">
        {items.map(({ pid, pname, restaurantName, price }) => (
          <div className="cart-item">
            <h1>{pname}</h1>
            <h3>{restaurantName}</h3>
            <p>Price: &#8377; {price}</p>
          </div>
        ))}
      </div>
      {!items.length ? <h2>You don't have any orders</h2> : null}
    </div>
  );
};
const mapStateToProps = (state) => ({
  items: state.orders.orders,
});

export default connect(mapStateToProps, { getUserOrders })(Orders);
