import React, { useState } from "react";
import { connect } from "react-redux";
import { loginUser } from "../../actions/user";
import { Redirect } from "react-router-dom";
import Alert from "../alert";
const Login = ({ loginUser, isAuthenticated, isUser }) => {
  const [state, setState] = useState({
    email: "",
    password: "",
  });
  const handleText = (e) => {
    setState({
      ...state,
      [e.target.name]: e.target.value,
    });
  };
  const submitForm = (e) => {
    e.preventDefault();
    const { email, password } = state;
    loginUser(email, password);
  };
  if (isUser) return <Redirect to="/user/dashboard" />;
  if (isAuthenticated) return <Redirect to="/" />;
  return (
    <div className="blur">
      <form onSubmit={submitForm} className="form">
        <Alert />
        <a href="/" className="home-btn">
          +
        </a>
        <h1>Login Form</h1>
        <div>
          <label>Email</label>
          <input type="email" name="email" onChange={handleText} required />
          <label>Password</label>
          <input
            type="password"
            name="password"
            onChange={handleText}
            required
          />
          <input type="submit" value="Login" className="gradient1" />
        </div>
        <a href="/user/register">Don't have an account ? Create one now...</a>
        <a href="/restaurant/login">Not a user. Continue as restaurant</a>
      </form>
    </div>
  );
};
const mapStateToProps = (state) => ({
  isAuthenticated:
    state.user.isAuthenticated || state.restaurant.isAuthenticated,
  isRestaurant: state.user.isAuthenticated,
});
export default connect(mapStateToProps, { loginUser })(Login);
