import React, { useState } from "react";
import { connect } from "react-redux";
import { registerUser } from "../../actions/user";
import { Redirect } from "react-router-dom";
import Alert from "../alert";
const Register = ({ registerUser, isAuthenticated }) => {
  const [state, setState] = useState({
    username: "",
    email: "",
    password: "",
    preference: "veg",
  });
  const handleText = (e) => {
    setState({
      ...state,
      [e.target.name]: e.target.value,
    });
  };
  const changePreference = (e) => {
    setState({ ...state, preference: e.target.value });
  };
  const submitForm = (e) => {
    e.preventDefault();
    const { username, email, password, preference } = state;
    registerUser(username, email, password, preference);
  };
  if (isAuthenticated) return <Redirect to="/" />;
  return (
    <div className="blur">
      <form onSubmit={submitForm} className="form">
        <Alert />
        <a href="/" className="home-btn">
          +
        </a>
        <h1>Registration form</h1>
        <div>
          <label>Username</label>
          <input type="text" name="username" onChange={handleText} required />
          <label>Email</label>
          <input type="email" name="email" onChange={handleText} required />
          <label>Password</label>
          <input
            type="password"
            name="password"
            onChange={handleText}
            required
          />
          <div id="radio-group">
            <div>
              <input
                type="radio"
                value="veg"
                name="preference"
                onChange={(e) => changePreference(e)}
              />
              <span>Veg</span>
            </div>
            <div>
              <input
                type="radio"
                value="non-veg"
                name="preference"
                onChange={(e) => changePreference(e)}
              />
              <span>Non-Veg</span>
            </div>
          </div>
          <input type="submit" value="Register" className="gradient2" />
        </div>
        <a href="/user/login">Already have an account ? Login Now</a>
      </form>
    </div>
  );
};
const mapStateToProps = (state) => ({
  isAuthenticated:
    state.user.isAuthenticated || state.restaurant.isAuthenticated,
  isRestaurantAuthenticated: state.restaurant.isAuthenticated,
});

export default connect(mapStateToProps, { registerUser })(Register);
