import React from "react";
import { connect } from "react-redux";
import { removeFromCart } from "../../actions/cart";
import { placeOrder } from "../../actions/orders";
import Alert from "../alert";
const Cart = ({ items, removeFromCart, placeOrder }) => {
  return (
    <div id="cart">
      <h1>Your Cart includes:</h1>
      <Alert />
      <div id="cart-items">
        {items.map(({ pid, pname, restaurantName, price }) => (
          <div className="cart-item">
            <h1>{pname}</h1>
            <h3>{restaurantName}</h3>
            <p>Price: &#8377; {price}</p>
            <button onClick={() => removeFromCart(pid)}>
              <i class="far fa-trash-alt"></i>
            </button>
          </div>
        ))}
      </div>
      {items.length ? (
        <button onClick={() => placeOrder(items)} className="btn">
          Place Order
        </button>
      ) : null}

      {!items.length ? <h2>Cart is empty</h2> : null}
    </div>
  );
};
const mapStateToProps = (state) => ({
  items: state.cart.cart,
});

export default connect(mapStateToProps, { removeFromCart, placeOrder })(Cart);
