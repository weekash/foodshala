import React, { useEffect } from "react";
import "./App.css";
import Register from "./components/user/register";
import Login from "./components/user/login";
import RestaurantLogin from "./components/restaurant/login";
import RestaurantRegister from "./components/restaurant/register";
import Nav from "./components/nav";
import Banner from "./components/banner";
import { Switch, Link, Route } from "react-router-dom";
import { store, persistor } from "./store";
import { loadUser } from "./actions/user";
import { loadRestaurant } from "./actions/restaurant";
import { connect, Provider } from "react-redux";
import { BrowserRouter as Router } from "react-router-dom";
import setAuthHeader from "./helper/setAuthHeader";
import Home from "./components/home";
import { getAllProducts } from "./actions/products";
import Items from "./components/items";
import ProductForm from "./components/restaurant/productForm";
import RestaurantDashboard from "./components/restaurant/dashboard";
import PrivateUserRoute from "./components/user/privateRoute";
import PrivateRestaurantRoute from "./components/restaurant/privateRoute";
import Cart from "./components/user/cart";
import { RESTAURANT_AUTH_ERROR, USER_AUTH_ERROR } from "./actions/type";
import Orders from "./components/user/orders";
import { PersistGate } from "redux-persist/integration/react";
if (localStorage.token) {
  setAuthHeader(localStorage.token);
}
if (localStorage.rtoken) {
  setAuthHeader(localStorage.rtoken);
}
const App = () => {
  useEffect(() => {
    if (!localStorage.token && !localStorage.rtoken) {
      store.dispatch({ type: RESTAURANT_AUTH_ERROR });
      store.dispatch({ type: USER_AUTH_ERROR });
    }
    if (localStorage.token) {
      store.dispatch({ type: RESTAURANT_AUTH_ERROR });
      store.dispatch(loadUser());
    }
    if (localStorage.rtoken) {
      store.dispatch({ type: USER_AUTH_ERROR });
      store.dispatch(loadRestaurant());
    }
  }, []);
  return (
    <Provider store={store}>
      <PersistGate persistor={persistor}>
        <Router>
          <Nav />
          <Route path="/user/login" component={Login} />
          <Route path="/user/register" component={Register} />
          <Route path="/user/cart" component={Cart} />
          <PrivateUserRoute path="/user/orders" component={Orders} />
          <Route path="/restaurant/login" component={RestaurantLogin} />
          <Route path="/restaurant/register" component={RestaurantRegister} />
          <PrivateRestaurantRoute
            path="/restaurant/dashboard"
            component={RestaurantDashboard}
          />
          <PrivateRestaurantRoute
            path="/restaurant/addproduct"
            component={ProductForm}
          />
          <Route exact path="/" component={Home} />
        </Router>
      </PersistGate>
    </Provider>
  );
};

export default App;
