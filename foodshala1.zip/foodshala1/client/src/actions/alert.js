import { SET_ALERT, REMOVE_ALERT } from "./type";
import { v4 as uuidv4 } from "uuid";
const setAlert = (msg, alertType) => (dispatch) => {
  let id = uuidv4();
  dispatch({
    type: SET_ALERT,
    payload: { id, msg, alertType },
  });
  setTimeout(() => {
    dispatch({ type: REMOVE_ALERT, payload: id });
  }, 5000);
};

export default setAlert;
