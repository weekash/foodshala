import {
  ORDER_PLACED,
  ORDER_FAILED,
  CLEAR_CART,
  GET_USER_ORDERS,
  GET_USER_ORDERS_FAIL,
  GET_RESTAURANT_ORDERS,
  GET_RESTAURANT_ORDERS_FAIL,
} from "./type";
import axios from "axios";
import setAlert from "./alert";
export const placeOrder = (orders) => async (dispatch) => {
  try {
    const config = {
      headers: {
        "Content-Type": "application/json",
      },
    };
    const body = JSON.stringify(orders);
    const res = await axios.post("/api/orders/add", body, config);
    console.log(res);
    dispatch(setAlert("Wohoo ! Order Placed", "success"));
    dispatch({ type: ORDER_PLACED });
    dispatch({ type: CLEAR_CART });
  } catch (err) {
    console.log(err);
    dispatch(setAlert("To order you need to be logged in first ", "danger"));
    dispatch({ type: ORDER_FAILED });
  }
};

export const getUserOrders = () => async (dispatch) => {
  try {
    const res = await axios.get("/api/orders/user");
    console.log(res);
    dispatch({ type: GET_USER_ORDERS, payload: res.data.results });
  } catch (err) {
    dispatch({ type: GET_USER_ORDERS_FAIL });
  }
};

export const getRestaurantOrders = () => async (dispatch) => {
  try {
    const res = await axios.get("/api/orders/restaurant");
    dispatch({ type: GET_RESTAURANT_ORDERS, payload: res.data.results });
  } catch (err) {
    dispatch({ type: GET_RESTAURANT_ORDERS_FAIL });
  }
};
