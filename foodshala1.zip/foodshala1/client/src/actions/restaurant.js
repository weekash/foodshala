import {
  LOGIN_RESTAURANT_SUCCESS,
  REGISTER_RESTAURANT_SUCCESS,
  RESTAURANT_AUTH_ERROR,
  LOAD_RESTAURANT,
  LOGIN_RESTAURANT_FAIL,
  REGISTER_RESTAURANT_FAIL,
  LOGOUT,
} from "./type";
import axios from "axios";
import setAuthHeader from "../helper/setAuthHeader";
import setAlert from "./alert";

export const loadRestaurant = () => async (dispatch) => {
  try {
    let token = localStorage.rtoken;
    if (token) {
      setAuthHeader(token);
    }
    const res = await axios.get("/api/restaurant/");
    dispatch({
      type: LOAD_RESTAURANT,
      payload: res.data,
    });
  } catch (err) {
    console.log(err);
    dispatch({ type: RESTAURANT_AUTH_ERROR });
  }
};
export const registerRestaurant = (restaurantName, email, password) => async (
  dispatch
) => {
  const config = {
    headers: {
      "Content-Type": "application/json",
    },
  };

  const body = JSON.stringify({ restaurantName, email, password });
  try {
    const res = await axios.post("/api/restaurant/register", body, config);
    dispatch({
      type: REGISTER_RESTAURANT_SUCCESS,
      payload: res.data,
    });
    dispatch(loadRestaurant());
  } catch (err) {
    console.log(err);
    dispatch({
      type: REGISTER_RESTAURANT_FAIL,
    });
  }
};

export const loginRestaurant = (email, password) => async (dispatch) => {
  const config = {
    headers: {
      "Content-Type": "application/json",
    },
  };

  const body = JSON.stringify({ email, password });
  try {
    const res = await axios.post("/api/restaurant/login", body, config);
    dispatch({
      type: LOGIN_RESTAURANT_SUCCESS,
      payload: res.data,
    });
    dispatch(loadRestaurant());
  } catch (err) {
    console.log(err.response);
    dispatch({
      type: LOGIN_RESTAURANT_FAIL,
    });
    let errors = err.response.data.errors;
    if (errors) {
      errors.forEach((error) => {
        dispatch(setAlert(error.msg, "danger"));
      });
    }
    console.log(err);
  }
};

export const logout = () => (dispatch) => {
  localStorage.removeItem("rtoken");
  localStorage.removeItem("token");
  dispatch({ type: LOGOUT });
};
