import {
  GET_PRODUCTS,
  GET_PRODUCTS_FAIL,
  GET_PRODUCTS_BY_ID,
  GET_PRODUCTS_BY_ID_FAIL,
} from "./type";
import axios from "axios";
import setAlert from "../actions/alert";
import { ADD_PRODUCT_FAIL, ADD_PRODUCT_SUCCESS } from "./type";
export const getAllProducts = () => async (dispatch) => {
  try {
    const res = await axios.get("/api/products/");
    dispatch({ type: GET_PRODUCTS, payload: res.data });
  } catch (err) {
    dispatch({ type: GET_PRODUCTS_FAIL });
  }
};

export const addProduct = (pname, price, info, category) => async (
  dispatch
) => {
  const config = {
    headers: {
      "Content-Type": "application/json",
    },
  };
  const body = JSON.stringify({ pname, price, info, category });

  try {
    const res = await axios.post("/api/products/add", body, config);
    dispatch({ type: ADD_PRODUCT_SUCCESS });
    dispatch(setAlert("Product Added Successfully", "success"));
  } catch (err) {
    console.log(err);
    dispatch({ type: ADD_PRODUCT_FAIL });
  }
};

export const getMyProducts = () => async (dispatch) => {
  try {
    const res = await axios.get("/api/products/myproducts");
    dispatch({ type: GET_PRODUCTS_BY_ID, payload: res.data });
  } catch (err) {
    console.log(err);
    dispatch({ type: GET_PRODUCTS_BY_ID_FAIL });
  }
};
