import {
  LOGIN_USER_SUCCESS,
  REGISTER_USER_SUCCESS,
  LOAD_USER,
  USER_AUTH_ERROR,
  LOGOUT,
  LOGIN_USER_FAIL,
} from "./type";
import axios from "axios";
import setAuthHeader from "../helper/setAuthHeader";
import setAlert from "../actions/alert";
export const loadUser = () => async (dispatch) => {
  let token = localStorage.token;
  if (token) {
    setAuthHeader(token);
  }
  try {
    const res = await axios.get("/api/user/");
    dispatch({
      type: LOAD_USER,
      payload: res.data,
    });
  } catch (err) {
    console.log(err);
    dispatch({ type: USER_AUTH_ERROR });
  }
};
export const registerUser = (username, email, password, preference) => async (
  dispatch
) => {
  const config = {
    headers: {
      "Content-Type": "application/json",
    },
  };

  const body = JSON.stringify({ username, email, password, preference });
  try {
    const res = await axios.post("/api/user/register", body, config);

    dispatch({
      type: REGISTER_USER_SUCCESS,
      payload: res.data,
    });
    dispatch(loadUser());
  } catch (err) {
    console.log(err);
  }
};

export const loginUser = (email, password) => async (dispatch) => {
  const config = {
    headers: {
      "Content-Type": "application/json",
    },
  };

  const body = JSON.stringify({ email, password });
  try {
    const res = await axios.post("/api/user/login", body, config);

    dispatch({
      type: LOGIN_USER_SUCCESS,
      payload: res.data,
    });
    dispatch(setAlert("Logged In Successfully", "success"));
    dispatch(loadUser());
  } catch (err) {
    let errors = err.response.data.errors;
    console.log(errors);
    errors.forEach((error) => {
      dispatch(setAlert(error.msg, "danger"));
    });
    dispatch({
      type: LOGIN_USER_FAIL,
    });
  }
};

export const logout = () => (dispatch) => {
  localStorage.removeItem("token");
  localStorage.removeItem("rtoken");
  dispatch({ type: LOGOUT });
};
