const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const auth = require("../../middleware/auth");
const jwt = require("jsonwebtoken");
const db = require("../../db");

// @route GET api/user/
// @desc  load a user or get  a user info
// @access Private

router.get("/", auth, async (req, res) => {
  const id = req.user.id;

  db.query(
    "SELECT username, email, preference FROM users WHERE id = ?",
    [id],
    (err, results) => {
      if (err) {
        console.log(error);
        res.status(401).send({ errors: [{ msg: "Can't find user" }] });
      }
      res.send(results[0]);
    }
  );
});

// @route POST api/user/register
// @desc  user registration
// @access Public

router.post("/register", async (req, res) => {
  const { email, password, username, preference } = req.body;
  db.query(
    "SELECT email FROM users WHERE email = ?",
    [email],
    async (error, results) => {
      if (error) {
        console.log(error);
      }
      if (results.length > 0) {
        console.log("User already exists");
        res.status(400).send({ errors: [{ msg: "User already exists" }] });
      } else {
        let hashedPassword = await bcrypt.hash(password, 10);
        db.query(
          "INSERT INTO users SET  ?",
          {
            username: username,
            email: email,
            password: hashedPassword,
            preference: preference,
          },
          (result, error) => {
            if (error) {
              console.log(error);
            }
            db.query(
              "SELECT id FROM users WHERE email=?",
              [email],
              (error, result) => {
                if (error) {
                  console.log(error);
                }

                let payload = {
                  user: {
                    id: result[0].id,
                  },
                };
                jwt.sign(
                  payload,
                  process.env.JWT_SECRET,
                  { expiresIn: 36000 },
                  (err, token) => {
                    if (err) console.log(err);
                    else res.json({ token });
                  }
                );
              }
            );
            // res.send({ message: "User registered successfully" });
          }
        );
      }
    }
  );
});
// @route POST api/user/login
// @desc  user login
// @access Public

router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    db.query(
      "SELECT * FROM users WHERE email = ?",
      [email],
      async (error, results) => {
        if (error) {
          console.log(error);
          return res.status(500).json({ message: "Some error occured" });
        }

        if (!results.length) {
          console.log("inv-alid credentials");
          return res
            .status(400)
            .json({ errors: [{ msg: "Invalid Credentials" }] });
        }
        let isValid = await bcrypt.compare(password, results[0].password);
        console.log(isValid);
        if (!isValid) {
          console.log("invalid credentials");
          return res
            .status(400)
            .json({ errors: [{ msg: "Invalid Credentials" }] });
        }
        const payload = {
          user: {
            id: results[0].id,
          },
        };
        jwt.sign(payload, process.env.JWT_SECRET, (err, token) => {
          if (err) throw err;
          else {
            res.json({ token });
          }
        });
      }
    );
  } catch (error) {
    res.send("Server Error");
    console.log(error);
  }
});

module.exports = router;
