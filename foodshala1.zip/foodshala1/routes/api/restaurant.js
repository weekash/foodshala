const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const auth = require("../../middleware/restaurantauth");
const jwt = require("jsonwebtoken");
const db = require("../../db");

// @route POST api/restaurant/
// @desc  load a restaurant
// @access Private

router.get("/", auth, async (req, res) => {
  db.query(
    "SELECT restaurantname, email FROM restaurants WHERE rid = ?",
    [req.restaurant.rid],
    (err, results) => {
      if (err) {
        console.log(error);
        res.status(401).send({ errors: [{ msg: "Cant find restaurant" }] });
      }
      res.send(results[0]);
    }
  );
});

// @route POST api/restaurant/register
// @desc  user registration
// @access Public
router.post("/register", async (req, res) => {
  const { email, password, restaurantName } = req.body;

  db.query(
    "SELECT email FROM restaurants WHERE email = ?",
    [email],
    async (error, results) => {
      if (error) {
        console.log(error);
        res.send({ errors: [{ msg: "Something wrong happened" }] });
      }
      if (results.length > 0) {
        console.log("Restaurant is already registered");
        res.send({ message: "Restaurant is already registered" });
      }
      let hashedPassword = await bcrypt.hash(password, 10);
      db.query(
        "INSERT INTO restaurants SET  ?",
        {
          restaurantName: restaurantName,
          email: email,
          password: hashedPassword,
        },
        (results, error) => {
          if (error) {
            console.log(error);
          }
          db.query(
            "SELECT rid FROM restaurants WHERE email=?",
            [email],
            (error, results) => {
              if (error) {
                console.log(error);
              }
              const payload = {
                restaurant: {
                  rid: results[0].rid,
                },
              };
              jwt.sign(
                payload,
                process.env.JWT_SECRET,
                { expiresIn: 36000 },
                (err, token) => {
                  if (err) {
                    console.log(err);
                  }
                  res.json({ token });
                }
              );
            }
          );
          //res.send({ message: "Restaurant registered successfully" });
        }
      );
    }
  );
});
// @route POST api/restarurant/login
// @desc  restaurant login
// @access Public

router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    db.query(
      "SELECT * FROM restaurants WHERE email = ?",
      [email],
      async (error, results) => {
        if (error) {
          return res
            .status(400)
            .send({ errors: [{ msg: "Some error occured" }] });
        }
        if (!results.length) {
          return res
            .status(400)
            .send({ errors: [{ msg: "Invalid Credentials" }] });
        }
        let isValid = await bcrypt.compare(password, results[0].password);

        if (!isValid) {
          return res
            .status(401)
            .send({ errors: [{ msg: "Invalid Credentials" }] });
        }
        const payload = {
          restaurant: {
            rid: results[0].rid,
          },
        };
        jwt.sign(payload, process.env.JWT_SECRET, (err, token) => {
          if (err) throw err;
          else {
            token;
            res.json({ token });
          }
        });
      }
    );
  } catch (error) {
    res.send("Server Error");
    console.log(error);
  }
});

module.exports = router;
