const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const auth = require("../../middleware/restaurantauth");
const db = require("../../db");

// @route GET api/products/
// @desc  load all items
// @access Public
router.get("/", async (req, res) => {
  db.query(
    "SELECT products.pid,products.pname,products.price,products.info,products.category,restaurants.restaurantName,restaurants.rid FROM products JOIN restaurants ON products.rid = restaurants.rid",
    (err, result) => {
      if (err) {
        console.log(err);
        res.status(500).send({ errors: [{ msg: "Cant find anything here" }] });
      }

      res.send({ products: result });
    }
  );
});

// @route GET api/myproducts/
// @desc  load my products
// @access Private
router.get("/myproducts", auth, async (req, res) => {
  const id = req.restaurant.rid;
  db.query(
    "SELECT pid,pname,price,info,category FROM products WHERE rid=?",
    [id],
    (err, result) => {
      if (err) {
        console.log(err);
        res.status(500).send({ errors: [{ msg: "Cant find anything here" }] });
      }
      res.send({ products: result });
    }
  );
});

router.post("/add", auth, async (req, res) => {
  const { pname, price, info, category } = req.body;
  db.query(
    "INSERT INTO products SET ? ",
    {
      pname: pname,
      rid: req.restaurant.rid,
      price: price,
      info: info,
      category: category,
    },
    (error, result) => {
      if (error) {
        console.log(error);
        return res.status(500).send({ errors: [{ msg: "Cant add item" }] });
      }
      res.send({ item: req.body });
      //return result;
    }
  );
});

module.exports = router;
