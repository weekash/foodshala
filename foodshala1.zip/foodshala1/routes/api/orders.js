const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const auth = require("../../middleware/auth");
const rauth = require("../../middleware/restaurantauth");
const db = require("../../db");

router.get("/user", auth, async (req, res) => {
  const id = req.user.id;
  console.log(id);
  db.query(
    "SELECT products.pname,products.price,products.category,restaurants.restaurantName,orders.status FROM products,restaurants,orders WHERE restaurants.rid=orders.rid AND products.pid = orders.pid AND orders.userid = ?",
    [id],
    (error, results) => {
      if (error) {
        console.log(error);
        res.status(500).send({ errors: [{ msg: "Something wrong happened" }] });
      }
      res.send({ results });
    }
  );
  // res.send("hello");
});

router.get("/restaurant", rauth, async (req, res) => {
  const id = req.restaurant.rid;
  console.log(id);
  db.query(
    "SELECT products.pname,products.price,products.category,users.username,orders.status FROM products,users,orders WHERE users.id=orders.userid AND products.pid = orders.pid AND orders.rid = ?",
    [id],
    (error, results) => {
      if (error) {
        console.log(error);
        res.status(500).send({ errors: [{ msg: "Something wrong happened" }] });
      }
      res.send({ results });
    }
  );
});

router.post("/add", auth, async (req, res) => {
  console.log("here");
  const ar = req.body;

  const userid = req.user.id;
  let orders = [];

  for (let i = 0; i < ar.length; i++) {
    let data = [ar[i].pid, ar[i].rid, userid, "ordered"];
    orders.push(data);
  }
  db.query(
    "INSERT INTO orders (pid,rid,userid,status) VALUES ?",
    [orders],
    (error, results) => {
      if (error) {
        console.log(error);
        res.send("something wrong");
      }
      res.send("Added Successfully");
    }
  );
});

module.exports = router;
